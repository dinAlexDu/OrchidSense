import requests
import random
import time
from datetime import datetime

while True:
    luminosidade = random.uniform(0, 50000)  # lux
    data_hora = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    sensor_data = {
        'data_hora': data_hora,
        'luminosidade': luminosidade
    }

    response = requests.post('http://localhost:5000/api/sensor_lux_data', json=sensor_data)

    if response.status_code == 200:
        print('Dados do simulador bh1750 enviados com sucesso para o servidor')
    else:
        print('Erro ao enviar dados do simulador BH1750 para o servidor')

    time.sleep(20)


