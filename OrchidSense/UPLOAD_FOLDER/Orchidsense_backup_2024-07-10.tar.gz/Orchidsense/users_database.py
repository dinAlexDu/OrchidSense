import logging
import mysql.connector
from mysql.connector import Error


def conectar():
    try:
        conn = mysql.connector.connect(
            host='127.0.0.1',
            database='orchidsense_db',
            user='pma',
            password='NtxFL6ms7pn3zRK2G9feDy'
        )
        return conn
    except Error as e:
        logging.error(f"Erro ao conectar ao MySQL: {e}")
        return None


def obter_dados_utilizadores():
    try:
        conn = conectar()
        if conn is None:
            return []

        cursor = conn.cursor()
        cursor.execute('SELECT id, email, first_name, last_name, profile_image, is_admin FROM users')
        users = cursor.fetchall()
        conn.close()
        return users
    except Error as e:
        logging.error(f"Erro ao obter dados dos utilizadores: {e}")
        if conn:
            conn.close()
        return []

def obter_utilizador_por_email(email):
    try:
        conn = conectar()
        if conn is None:
            return None

        cursor = conn.cursor()
        cursor.execute('SELECT id, email, password_hash, first_name, last_name, profile_image, is_admin FROM users WHERE email = %s', (email,))
        utilizador = cursor.fetchone()
        conn.close()
        return utilizador
    except Error as e:
        logging.error(f"Erro ao obter dados do utilizador: {e}")
        if conn:
            conn.close()
        return None


def obter_utilizador_por_id(user_id):
    try:
        conn = conectar()
        if conn is None:
            return None

        cursor = conn.cursor()
        cursor.execute('SELECT id, email, password_hash, first_name, last_name, profile_image, is_admin FROM users WHERE id = %s', (user_id,))
        utilizador = cursor.fetchone()
        conn.close()
        return utilizador
    except Error as e:
        logging.error(f"Erro ao obter dados do utilizador: {e}")
        if conn:
            conn.close()
        return None