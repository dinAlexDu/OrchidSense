import mysql.connector


def obter_dados_orquideas():
    try:
        conn = mysql.connector.connect(
            user='pma',
            password='NtxFL6ms7pn3zRK2G9feDy',
            host='127.0.0.1',
            database='orchidsense_db'
        )

        cursor = conn.cursor()
        cursor.execute("SELECT * FROM orquideas")

        dados_orquideas = cursor.fetchall()

        cursor.close()
        conn.close()

        return dados_orquideas

    except mysql.connector.Error as err:
        print(f"Erro ao ligar à base de dados: {err}")
        return []




def get_configs_alertas(user_id):
    try:
        conn = mysql.connector.connect(
            user='pma',
            password='NtxFL6ms7pn3zRK2G9feDy',
            host='127.0.0.1',
            database='orchidsense_db'
        )

        cursor = conn.cursor()
        query = """
            SELECT uc.id, o.nome, uc.temp_min, uc.temp_max, uc.humidade_min, uc.humidade_max, uc.lux_min, uc.lux_max
            FROM user_configs uc
            JOIN orquideas o ON uc.orquidea_id = o.id
            WHERE uc.user_id = %s
        """
        cursor.execute(query, (user_id,))

        configuracoes_alertas = cursor.fetchall()

        cursor.close()
        conn.close()

        return configuracoes_alertas

    except mysql.connector.Error as err:
        print(f"Erro ao ligar à base de dados: {err}")
        return []

