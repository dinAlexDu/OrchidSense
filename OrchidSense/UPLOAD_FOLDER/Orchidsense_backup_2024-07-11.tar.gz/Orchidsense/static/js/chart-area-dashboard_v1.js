// Set new default font family and font color to mimic Bootstrap's default styling
(Chart.defaults.global.defaultFontFamily = "Metropolis"),
    '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = "#858796";


// Função utilitária para formatação de números

function number_format(number, decimals, dec_point, thousands_sep) {
    // *     example: number_format(1234.56, 2, ',', ' ');
    // *     return: '1 234,56'
    number = (number + "").replace(",", "").replace(" ", "");
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
        sep = typeof thousands_sep === "undefined" ? "," : thousands_sep,
        dec = typeof dec_point === "undefined" ? "." : dec_point,
        s = "",
        toFixedFix = function (n, prec) {
            var k = Math.pow(10, prec);
            return "" + Math.round(n * k) / k;
        };
    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : "" + Math.round(n)).split(".");
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || "").length < prec) {
        s[1] = s[1] || "";
        s[1] += new Array(prec - s[1].length + 1).join("0");
    }
    return s.join(dec);
}

// GRÁFICOS
// Area Chart Dashboard

// GRÁFICOS
// Area Chart Dashboard

document.addEventListener("DOMContentLoaded", function () {
    var ctxTemp = document.getElementById("temperatura-chart").getContext("2d");
    var chartTemperatura = new Chart(ctxTemp, {
        type: 'line',
        data: {
            labels: window.chartData.labels,
            datasets: [{
                label: 'Temperatura (°C)',
                data: window.chartData.temperaturas,
                fill: true,
                backgroundColor: 'rgba(232, 21, 0, 0.2)',  // Vermelho claro
                borderColor: 'rgba(232, 21, 0, 1)',        // Vermelho sólido
                pointBackgroundColor: 'rgba(232, 21, 0, 1)', // Vermelho pontos
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgba(232, 21, 0, 1)', // Vermelho pontos mouse
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });

    var ctxHum = document.getElementById("humidade-chart").getContext("2d");
    var chartHumidade = new Chart(ctxHum, {
        type: 'line',
        data: {
            labels: window.chartData.labels,
            datasets: [{
                label: 'Humidade (%)',
                data: window.chartData.humidades,
                fill: true,
                backgroundColor: 'rgba(0, 207, 213, 0.2)', // Cyan fundo
                borderColor: 'rgba(0, 207, 213, 1)',       // Cyan linha
                pointBackgroundColor: 'rgba(0, 207, 213, 1)', // Cyan pontos
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgba(0, 207, 213, 1)', // Cyan pontos mouse
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });

    var ctxLum = document.getElementById("luminosidade-chart").getContext("2d");
    var chartLuminosidade = new Chart(ctxLum, {
        type: 'line',
        data: {
            labels: window.chartData.labels,
            datasets: [{
                label: 'Luminosidade (lux)',
                data: window.chartData.luminosidades,
                fill: true,
                borderColor: 'rgba(244, 161, 0, 1)',       // Amarelo linha
                backgroundColor: 'rgba(244, 161, 0, 0.2)', // Amarelo fundo
                pointBackgroundColor: 'rgba(244, 161, 0, 1)', // Amarelo pontos
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgba(244, 161, 0, 1)', // Amarelo mouse
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });
});








