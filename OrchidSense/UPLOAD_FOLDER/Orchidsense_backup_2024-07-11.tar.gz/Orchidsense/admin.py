from flask import Blueprint, render_template, abort
from flask_login import login_required, current_user

# Blueprint
admin_bp = Blueprint('admin', __name__, template_folder='templates')

@admin_bp.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        abort(403)
    return render_template('admin_dashboard.html')

@admin_bp.route('/admin/data')
@login_required
def admin_data():
    if not current_user.is_admin:
        abort(403)
    return render_template('admin_data.html')
